<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.6/css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
<form action="login1.php" method="post" class="col s12 m10 l8 offset-m1 offset-l2">
</div>
                    					<div class="input-field col s12">
						<i class="fa fa-user prefix" aria-hidden="false"></i>
						<input id="password1" name="password1" type="text" class="validate" required>
						<label for="password1">User Name</label>
					</div>
					</div>
					<div class="input-field col s12">
						<i class="fa fa-key prefix" aria-hidden="false"></i>
						<input id="password" name="password" type="password" class="validate" required>
						<label for="password">Password</label>
					</div>
                    					<div class="input-field col s12">
						<i class="fa fa-download prefix" aria-hidden="false"></i>
						<input id="password1" name="password1" type="text" class="validate" required>
						<label for="password1">File Size Enter 128MB</label>
					</div>
				 </div>
                    					<div class="input-field col s12">
						<i class="fa fa-lock prefix" aria-hidden="false"></i>
						<input id="password2" name="password2" type="password" class="validate" required>
						<label for="password2">Hash</label>
					</div>
<button class="btn waves-effect waves-light amber col s12" type="submit">Login</button>