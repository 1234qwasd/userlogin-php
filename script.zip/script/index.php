<script type="text/javascript" src="http://cpanel.byethost.com/panel/pl-res/js/master-legacy.cmb.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://cpanel.byethost.com/panel/pl-res/css/original.master-ltr.cmb.min.css" />
<link rel="stylesheet" type="text/css" href="http://cpanel.byethost.com/panel/pl-res/css/chosen.min.css" />
<input class='btn btn-primary' id="Submit" type="submit" onclick="window.location='login.php';" value="Login" /> 
<input class='btn btn-primary' id="Submit" type="submit" onclick="window.location='login.php';" value="Signup" /> 